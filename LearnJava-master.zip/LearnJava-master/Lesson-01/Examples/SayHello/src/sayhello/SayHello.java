/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sayhello;

/**
 *
 * @author mafudge
 */
public class SayHello {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String yourName;    // Set aside some memory, refer to it as yourName
        yourName = "Tony";  // set memory at yourName to value "Tony"
        System.out.printf("Hello, %s!!!!!\n", yourName); // say hello
    }
}
