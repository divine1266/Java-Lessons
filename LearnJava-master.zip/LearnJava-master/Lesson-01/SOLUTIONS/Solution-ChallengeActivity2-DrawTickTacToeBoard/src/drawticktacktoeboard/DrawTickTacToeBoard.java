/* Challenge Activity 2
 * Write a java program which uses System.out to draw this tic-tac-toe board:
 * 
 *     |   |
 *   X | X | O
 *  ---+---+---
 *   O | O |    
 *  ---+---+---
 *   X |   |   
 *     |   |
 */

package drawticktacktoeboard;

public class DrawTickTacToeBoard {

    public static void main(String[] args) {
        System.out.println("     |   |");
        System.out.println("   X | X | 0");
        System.out.println("  ---+---+---");
        System.out.println("   0 | 0 |");   
        System.out.println("  ---+---+---");
        System.out.println("   X |   |");   
        System.out.println("     |   |");
    }
}
